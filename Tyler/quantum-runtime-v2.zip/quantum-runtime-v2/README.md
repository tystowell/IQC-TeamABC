# Quantum Circuit Runtime Predictor (v2)

Our entry for the [Quantum Rings Circuit Runtime Prediction Challenge](https://github.com/Quantum-Rings/quantumrings-challenge-iqc-2026): given an OpenQASM circuit and a simulator `threshold`, predict how many seconds the simulation takes.

The automated score is `max(0, 1 − |log10(predicted / actual)|)`, averaged over every run, so being off by 10× scores 0. It's worth 1/3 of the final score. Everyone on the team must be able to explain the whole submission, so please read [How it works](#how-it-works).

**v2 scores:** 89.3% on random held-out training circuits, 86.5% on groups of similar circuits, and 69.1% on algorithm families the model has never seen. See [How much to trust the scores](#how-much-to-trust-the-scores).

## What's new in v2
| Change | Why | Effect |
|---|---|---|
| **Shot-sampling term** in the physics formula | Runtime of shallow circuits grew with *measured qubits*, not gates: drawing 1024 shots costs about 7 ms per measured qubit, about 35 ms once the final state is entangled | Formula alone: 58% → 69% |
| **Swap-cost term** for long-range gates | Wide circuits with no entanglement cost 13–370 µs per gate depending on how far qubits must move | Included in the line above |
| Six new features: measured qubits, sampling cost, total swap distance, and the largest bond the qubit count allows | Lets the trees use the same findings | +0.3 to +0.7 |
| **Probe shortcut:** a gate between two unentangled qubits is applied directly, without swaps, when the result stays unentangled | The probe used to spend its budget moving qubits on wide circuits | Exact; covers up to 50× more of unentangled wide circuits; score about the same |
| Gates dropped when the probe's budget runs out now mark the run as stopped early | A hidden case where the probe reported finishing when it hadn't | Correctness |

| Test | v1 | v2 |
|---|---:|---:|
| Official `run.py` + `score.py`, 108 held-out circuits | 86.75% | **87.53%** |
| Random circuits held out | 88.2% | **89.3%** |
| Similar circuits held out | 85.5% | **86.5%** |
| Unseen gate-set families | 65.1% | **69.1%** |
| Slowest circuit (limit 15 s) | 8.4 s | 8.6 s |

Tried and **not** adopted: probes started partway through the circuit (no gain), and a small neural network (gains about 0.5 on familiar circuits but loses up to 6 points on unseen families).

## Quick start
Tested with Python 3.13. The included `analysis/profile_features.csv` holds features for the training circuits, so training doesn't need them recalculated.

```bash
# 1. Install
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 2. Get the training data from the challenge repo (it isn't stored here)
git clone git@github.com:Quantum-Rings/quantumrings-challenge-iqc-2026.git ../challenge
cp ../challenge/train-runtime-data.csv .
cp -r ../challenge/train-circuits .

# 3. Check that everything works
python tests/test_profile.py
python tests/test_probe.py

# 4. Train (under a minute)
python analysis/train_model.py
```

Step 4 writes `submission-harness/artifacts/runtime_model.joblib`. This file isn't committed because it only loads reliably with the `scikit-learn` version that created it, so each person trains their own copy.

## Making a submission
The hold-out circuits arrive in the challenge repo during the final hours of the event.

```bash
git -C ../challenge pull
cd submission-harness
python run.py --team "Your Team Name" --circuits ../../challenge/holdout-circuits
```

This writes `submission.csv`, which is sent to the organizers as a DM. To run faster, use `python run_parallel.py` with the same options plus `--workers 4`. It runs the same unmodified `run.py` on batches and merges the results, and on our test its predictions matched a normal run exactly.

Before sending it:
- Check the end of the output for a `WARNING` about the 15 s limit. If `run_parallel.py` warns, try fewer workers.
- Close other heavy programs while it runs, because the file records how long each circuit took.
- Train on all circuits first. `analysis/train_model.py` does this by default.

## How it works
Runtime depends far less on line count or qubit count than on **how much entanglement a circuit builds**, capped by `threshold`. Circuits with mid-circuit measurement or `reset` are a separate, much slower case.

```text
QASM text
  ├─ Structural profile: estimates entanglement at each cut between neighboring qubits
  ├─ Small simulations: measure real entanglement at bond dimensions 8 and 16
  └─ Counts: gate mix, depth, interaction graph, recognized algorithm blocks
        ↓
  model inputs for each circuit and threshold
        ↓
  average, in log space, of:
    ├─ trees predicting runtime directly
    └─ a physics formula + trees predicting its error
        ↓
  predicted seconds
```

- **Structural profile ([`entanglement_profile.py`](entanglement_profile.py)):** reads the circuit as a stream and combines three estimates of entanglement at each cut. A structural bound adds each gate's entangling power, a group bound tracks which qubits have been linked, and a stabilizer tableau follows Clifford gates exactly. It also spots gates that can't entangle, such as `cx` with a `|0⟩` control, and gates that undo each other.
- **Small simulations ([`mps_probe.py`](mps_probe.py)):** a compact matrix-product-state simulation at very low bond dimension. It doesn't try to reproduce the simulator's results. It measures singular values, which structure alone can't predict. A gate between two qubits that are both unentangled is applied directly, without moving qubits, whenever the result stays unentangled. This is exact, and lets the simulation get much further through wide circuits.
- **Prediction ([`submission-harness/model.py`](submission-harness/model.py)):** the physics formula below is fitted to the training data, and trees learn what it misses.

```text
seconds = startup + a × ops + b × ops (dynamic circuits only)
        + c × Σ gate crossings × min(2^bits, threshold)^p
        + d × measured qubits × (1 + e × final state entangled)
        + f × total swap distance of long-range gates
```

The last two terms came from studying the worst predictions. Drawing 1024 shots costs about 7 ms per measured qubit, or about 35 ms once the final state is entangled. Long-range gates cost about 1.4 µs per swap. The fitted formula alone rose from 58% to 69% with them, and they raised the full model's score on unseen families by about 4 points.

## What's in this repo

| Path | Purpose |
|---|---|
| `submission-harness/model.py` | **The model:** features and prediction |
| `submission-harness/run.py`, `score.py` | Organizers' harness and scorer; don't edit |
| `submission-harness/run_parallel.py` | Runs `run.py` on batches at once, then merges the results |
| `entanglement_profile.py` | Structural entanglement estimate, plus `plot_entanglement_profile()` |
| `mps_probe.py` | Small simulations |
| `visualize_qasm.py` | QASM parser, plus `visualize_qasm()` and `parse_qasm()` for looking at circuits |
| `visualize_example.py` | Short example of reading and drawing a circuit |
| `analysis/train_model.py` | Trains the final model |
| `analysis/profile_features.py` | Recalculates `analysis/profile_features.csv` |
| `analysis/profile_features.csv` | Saved features for the 532 training circuits |
| `analysis/evaluate_model.py` | Scores the model on held-out circuits; `--full` compares each model change (about 30 minutes) |
| `analysis/timing_check.py` | Times the slowest circuits against the 15 s limit (about 2 minutes) |
| `tests/` | Known-answer checks |

**Changing the model:** if you change `entanglement_profile.py`, `mps_probe.py`, or the feature code in `model.py`, recalculate the features (`python analysis/profile_features.py --workers 4`, about 5 minutes) and retrain. Models and saved features only work if they come from the same code. If you only change model settings, skip that step, retrain, and run `analysis/evaluate_model.py`.

## Looking at a circuit

```python
from entanglement_profile import plot_entanglement_profile
from visualize_qasm import visualize_qasm

visualize_qasm("train-circuits/0071a13b.qasm.zst", out="circuit.png")
plot_entanglement_profile("train-circuits/0071a13b.qasm.zst", out="profile.png")
```

## How much to trust the scores
Never measure accuracy on circuits the model trained on: this model scores about 97% there, which means nothing. `analysis/evaluate_model.py` uses three tests, from easiest to hardest:

| Test | What's held out | v2 score |
|---|---|---:|
| Random circuits | Individual circuits | 89.3% |
| Similar circuits | Groups of circuits of similar size | 86.5% |
| Unseen families | All circuits sharing a gate set | 69.1% |

To reproduce them, run `python analysis/evaluate_model.py` (5–10 minutes, one seed). The official `run.py` and `score.py` also gave 87.53% on 108 held-out circuits, which is one split of the data.

For comparison, the organizers report 82.0% cross-validated and 77.9% on the hold-out. Those aren't direct comparisons because splits may differ.

## Where we still lose points
The similar-circuits test scores 86.5%, so 13.5 points are lost. About 1.5 of those are measurement noise: repeated runs of identical work differ by 3–5%.

| Group (each run counted once) | Points lost | Share of loss | Score in group |
|---|---:|---:|---:|
| Runs under 1 s (mostly predicted a little too slow) | 4.3 | 32% | 89% |
| Probe saw under half the circuit, predicted too fast | 2.2 | 16% | 65% |
| Probe saw under half the circuit, predicted too slow | 1.9 | 14% | 66% |
| Probe saw most of the circuit but maxed out at bond dimension 16 | 1.8 | 13% | 93% |
| Probe saw most of the circuit, not maxed out | 1.4 | 10% | 90% |
| Dynamic circuits (`reset` / `if`, simulated once per shot) | 1.3 | 9% | 75% |
| Near the 6-hour cap | 0.4 | 3% | 77% |
| Noisy labels (runtime jumps against its own trend) | 0.3 | 2% | 37% |

By circuit type, Trotter-like `cx`+`rz`+`rx` circuits (75%) and `rzz` Ising/QAOA circuits (63%) are 15% of circuits but lose 4.3 points.

## Known limits
- **Open rules question:** the challenge says to predict runtime "without running it". The small simulations aren't the real simulator, but they do simulate the circuit. Check this with the organizers before relying on them. To train without them, run `python analysis/train_model.py --no-probes`, which is less accurate but purely structural.
- **New algorithm types:** accuracy falls sharply for circuits unlike anything in training.
- **Very large circuits:** tracking stops after a fixed amount of work and the rest is extrapolated. These predictions are less accurate.
- **Slow machines:** timing was measured on one Mac, with a slowest circuit of 8.6 s. Run `python analysis/timing_check.py` to test your own machine. Features stay repeatable unless a machine is slow enough to hit the safety time limits.
- **Internals are inferred:** we don't have documentation of what `threshold` does. Treating it as a bond-dimension cap is our reading of the timing data.

## Credits
`submission-harness/run.py` and `score.py` come from the [challenge repo](https://github.com/Quantum-Rings/quantumrings-challenge-iqc-2026), which is also the source of the circuits and runtime labels.
